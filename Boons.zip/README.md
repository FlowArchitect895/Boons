# Boons — skill refinement bundle

This bundle provides replacement `SKILL.md` files for the six existing Boons modules, preserving repository paths.

| Skill | Version |
|---|---:|
| `coding/craft-and-vibe` | 0.3.0 |
| `creative/voice-and-edit` | 0.2.0 |
| `creative/systems-synthesis` | 0.2.0 |
| `cybersecurity/security-methods` | 0.2.0 |
| `cybersecurity/bug-bounty-recon` | 0.2.0 |
| `meta/rea-amplify` | 0.2.0 |

## Apply manually

1. Extract the ZIP.
2. Copy the six skill folders into the matching locations in your Boons repository.
3. Replace only the existing `SKILL.md` files.
4. Run `python3 tools/validate.py` and the provenance check described in the repository's documentation.
5. Run fresh-session behavioral tests before treating these refinements as validated.

This bundle does not modify GitHub, repository tools or the license. Historical test results do not automatically validate these refined versions.
