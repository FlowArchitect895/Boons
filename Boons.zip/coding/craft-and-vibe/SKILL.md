---
name: craft-and-vibe
description: Build code by combining creative intent with disciplined engineering, explicit acceptance criteria, risk-based verification and a clean handoff.
license: Apache-2.0
metadata:
  domain: coding
  version: "0.3.0"
  status: experimental
user-invocable: true
---

# Craft and vibe

Treat the user's description as the brief. Infer what is safe to infer, ask when ambiguity changes the build, and apply engineering standards appropriate to the risk. The loop is **shape, weight, feel, build, prove, exit**.

## Workflow

1. **Read the shape.** Establish function, intended experience, smallest useful scope and output form. Identify users and runtime environment when relevant. In an existing project, inspect instructions, relevant source, tests, dependencies and version-control state before editing. Preserve unrelated and untracked work.
2. **Set the weight.** Match effort to consequence, complexity, lifespan and reversibility. A disposable helper does not need product infrastructure. Software handling accounts, private data, money, safety or security boundaries deserves stronger controls. Prefer the simplest architecture that meets the need; justify dependencies and abstractions. State assumptions and ask when an unresolved choice changes architecture, data handling, security or experience.
3. **Catch the feel.** Identify the few details that matter: interaction pace, visual hierarchy, response behavior, accessibility, tone or a key moment. Translate them into observable acceptance criteria. Keep functional requirements distinct from visual preferences; polish is not proof of correctness.
4. **Define the smallest whole.** Write a compact acceptance checklist for the core journey and constraints. Include expected inputs, outputs, errors and boundary conditions. Build a coherent working slice, follow project conventions, make reversible changes, and preserve unrelated code and data. Handle invalid input and expected failures deliberately.
5. **Build with safeguards.** Validate inputs at trust boundaries. Never hardcode credentials. Consider permissions, data exposure, injection, dependency provenance and destructive side effects where relevant. Minimize data collection. Consider confirmation, rollback or recovery for consequential state changes. Do not install, access external services, deploy, publish or push without authorization.
6. **Prove it.** Choose checks by risk: unit tests for logic, integration tests for boundaries, end-to-end tests for critical journeys, and manual inspection for visual details. Test normal use, invalid input, empty/missing data, boundaries, failure paths and relevant permissions. For fixes, include a regression check. Inspect diffs for unintended changes. Exercise visual/interactive paths, including responsiveness and keyboard access where applicable. If a check cannot run, say why. Never report an unrun test as passing.
7. **Exit clean.** Deliver the result, what changed, how to run it, exact checks and outcomes, assumptions, limitations and unverified areas. Mention operational requirements or migrations. Offer the next useful increment without gold-plating.

## Stop or narrow

Pause before proceeding if ambiguity changes architecture or safety; credentials or permissions are missing; the next step installs, publishes, pushes, deploys, overwrites or deletes; an external dependency adds material cost/privacy/security implications; or scope expands beyond the smallest useful whole. Proceed only with a safe, reversible step and stated assumptions.

## Verification and handoff

Report separately:
- **Implemented:** behavior present in the code.
- **Tested:** exact commands, cases or paths actually exercised and results.
- **Not tested:** unavailable environments, integrations or checks not run.
- **Known risks:** unresolved defects, assumptions and operational dependencies.

A preview or written code is not proof. Confirm acceptance criteria, honest test reporting, regression consideration and preservation of unrelated work. If a test fails, report it and do not call the build fully passing.
